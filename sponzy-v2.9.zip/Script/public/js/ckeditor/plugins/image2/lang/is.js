/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'is', {
	alt: 'Baklægur texti',
	btnUpload: 'Hlaða upp',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Almennt',
	lockRatio: 'Festa stærðarhlutfall',
	menu: 'Eigindi myndar',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Reikna stærð',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Eigindi myndar',
	uploadTab: 'Senda upp',
	urlMissing: 'Image source URL is missing.', // MISSING
	altMissing: 'Alternative text is missing.' // MISSING
} );
