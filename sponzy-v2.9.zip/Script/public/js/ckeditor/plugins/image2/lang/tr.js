/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'tr', {
	alt: 'Alternatif Yazı',
	btnUpload: 'Sunucuya Yolla',
	captioned: 'Başlıklı resim',
	captionPlaceholder: 'Başlık',
	infoTab: 'Resim Bilgisi',
	lockRatio: 'Oranı Kilitle',
	menu: 'Resim Özellikleri',
	pathName: 'Resim',
	pathNameCaption: 'başlık',
	resetSize: 'Boyutu Başa Döndür',
	resizer: 'Boyutlandırmak için, tıklayın ve sürükleyin',
	title: 'Resim Özellikleri',
	uploadTab: 'Karşıya Yükle',
	urlMissing: 'Resmin URL kaynağı bulunamadı.',
	altMissing: 'Alternatif yazı eksik.'
} );
